// Import CSS
import './styles/style.css';

// Import main JavaScript
import './js/main.js';

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
  console.log('Limousine service website loaded successfully');
});
